import React from "react";
import { Navbar } from "../components/Navbar";
import "../pages/Trending.css";


export const Trending = () => {
  return (
    <div className="Trending-container">
      <Navbar />
      <div className="Videos-conatainer">
        <div className="div">
          <video src="" controls height={250}></video>
          <h1>Video Description</h1>
        </div>
      </div>
      <div className="Videos-conatainer">
        <div className="div">
          <video src="" controls height={250}></video>
          <h1>Video Description</h1>
        </div>
      </div>
      <div className="Videos-conatainer">
        <div className="div">
          <video src="" controls height={250}></video>
          <h1>Video Description</h1>
        </div>
      </div>
      <div className="Videos-conatainer">
        <div className="div">
          <video src="" controls height={250}></video>
          <h1>Video Description</h1>
        </div>
      </div>
    </div>
  );
};

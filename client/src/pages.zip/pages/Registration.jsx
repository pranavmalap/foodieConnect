import React, { useState } from "react";
import "./Registration.css";
import axios from "axios";
import { useCookies } from "react-cookie";

export const Registration = () => {
  const [username, setUsername] = useState();
  const [email, setEmail] = useState();
  const [phone, setPhone] = useState();
  const [password, setPassword] = useState();
  const [reppassword, setReppassword] = useState();

  return (
    <RegiForm
      username={username}
      setUsername={setUsername}
      email={email}
      setEmail={setEmail}
      phone={phone}
      setPhone={setPhone}
      password={password}
      setPassword={setPassword}
      reppassword={reppassword}
      setReppassword={setReppassword}
    ></RegiForm>
  );
};

const RegiForm = ({
  username,
  setUsername,
  email,
  setEmail,
  phone,
  setPhone,
  password,
  setPassword,
  reppassword,
  setReppassword,
}) => {
  const handelSubmit = async (e) => {
    e.preventDefault();

    if (password != reppassword) {
      alert("password doest matches");
      return;
    }

    try {
      await axios.post("http://localhost:3001/auth/register", {
        username,
        email,
        phone,
        password,
        reppassword,
      });

      alert("Registration Done !!!");
    } catch (error) {
      console.error(error);
    }
  };
  return (
    <div className="container1">
      <div className="container2">
        <h1>Registration</h1>
        <p>Please fill this form to create an account. </p>
        <form name="registraion" onSubmit={handelSubmit}>
          <label for="name">
            <b>Name</b>
          </label>
          <input
            type="text"
            placeholder="Enter name"
            name="username"
            id="username"
            value={username}
            required
            onChange={(e) => setUsername(e.target.value)}
          ></input>
          <label for="email">
            <b>Email</b>
          </label>
          <input
            type="email"
            placeholder="Enter email"
            name="email"
            id="email"
            value={email}
            required
            onChange={(e) => setEmail(e.target.value)}
          ></input>
          <label for="phone">
            <b>Phone Number</b>
          </label>
          <input
            type="number"
            maxLength={10}
            placeholder="Enter phone number"
            name="phone"
            id="phone"
            value={phone}
            required
            onChange={(e) => setPhone(e.target.value)}
          ></input>
          <label for="pass">
            <b>Password</b>
          </label>
          <input
            type="password"
            placeholder="Enter password"
            name="password"
            id="password"
            value={password}
            required
            onChange={(e) => setPassword(e.target.value)}
          ></input>
          <label for="reppass">
            <b>Repeat Password</b>
          </label>
          <input
            type="password"
            placeholder="Repeat password"
            name="reppassword"
            id="reppassword"
            value={reppassword}
            required
            onChange={(e) => setReppassword(e.target.value)}
          ></input>
          <button type="submit" className="registrationbtn">
            Register
          </button>
        </form>
        <div className="containersignin">
          <p>
            Already have an account?
            <a href="login">Sign in</a>
          </p>
        </div>
      </div>
      <div className="image">
        <img src="./Images/register.png" alt="Cooking Image"></img>
      </div>
    </div>
  );
};

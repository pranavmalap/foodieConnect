import React, { useState, useEffect } from "react";
import axios from "axios";
import { Navbar } from "../components/Navbar";
import "./Home.css";
import { useGetUserID } from "../hooks/useGetUserID";

export const Home = (   ) => {
  const [recipes, setRecipes] = useState([]);
  const [savedRecipes, setSavedRecipes] = useState([]);
  const userID = useGetUserID();
  const [username, setUsername] = useState("");

  useEffect(() => {
    const fetchRecipe = async () => {
      try {
        const response = await axios.get("http://localhost:3001/recipes");
        setRecipes(response.data);
        // console.log(response.data);
      } catch (err) {
        console.error(err);
      }
    };

    

    const fetchSavedRecipe = async () => {
      try {
        const response = await axios.get(
          `http://localhost:3001/recipes/savedRecipes/ids/${userID}`
        );
        setSavedRecipes(response.data.savedRecipes);
        // console.log(response.data);
      } catch (err) {
        console.error(err);
      }
    };


    const fetchUsername = async () => {
      try {
        await axios
          .get(`http://localhost:3001/recipes/username/${userID}`)
          .then((res) => {
            setUsername(res.data.username);
          });
      } catch (err) {
        console.log(err);
      }
    };

    // const fetchOwner = sync () =>{
    //   try{
    //     await axios(`http://localhost:3001/recipes/username/${userID}`)
    //   }
    // }

    fetchRecipe();
    fetchSavedRecipe();
    fetchUsername();
  }, []);

  const saveRecipe = async (recipeID) => {
    const userID = useGetUserID();
    try {
      const response = await axios.put("http://localhost:3001/recipes", {
        recipeID,
        userID,
      });
      setSavedRecipes(response.data.savedRecipes);
    } catch (err) {
      console.error(err);
    }
  };

  const isRecipeSaved = (id) => savedRecipes.includes(id);

  return (
    <div className="container">
      {/* <Navbar /> */}

      {/* <h1> Recipes </h1> */}
    
      {recipes.map((recipe) => (
        <div key={recipe._id} className="recipe-item">
           {console.log(localStorage.getItem("userID")) === recipe.userOwner}

          <div className="videoPart">
            {recipe.videos.map((video) => (
              <video controls preload="auto">
                <source src={`http://localhost:3001/${video}`} />
                Your browser does not support the video tag.
              </video>
            ))}
          </div>

          <div className="detailPart">
            <div className="username">{username && <h3> {username}</h3>}</div>
            <div>
              <h2 className="recipe-name">{recipe.name}</h2>
            </div>
            <div>
              <p className="recipe-instructions">{recipe.instructions}</p>
            </div>
            <div>
              <h3>Ingredients</h3>
              {/* <ul> */}

              <h3>{recipe.ingredients}</h3>

              {/* </ul> */}
            </div>
            <div>
              <p className="cooking-time">
                Cooking Time: {recipe.cookingTime} (minutes)
              </p>
            </div>
            <button
              onClick={() => saveRecipe(recipe._id)}
              disabled={isRecipeSaved(recipe._id)}
            >
              {isRecipeSaved(recipe._id) ? "Saved" : "Save"}
            </button>
          </div>
        </div>
      ))}
      {/* </ul> */}
    </div>
  );
};

import React, { useEffect, useState } from "react";
import { useGetUserID } from "../hooks/useGetUserID";
import axios from "axios";

const MyVideos = () => {
  const userID = useGetUserID();
  const [myrecipe , setMyrecipe] = useState([]);


  useEffect(() => {
   
    const myrecipes = async () => {
      try {
        const response = await axios.get(
          `http://localhost:3001/recipes/myrecipe/${userID}`
        );
        setMyrecipe(response.data);
        console.log(response.data);
      } catch (err) {
        console.log(err);
      }
    };
    myrecipes();
  }, []);


  return (
    <div className="container">
      <h1> My Video </h1>
      {myrecipe.map((recipe) => (
      <div className="recipe-item">
      {recipe.videos.map((video) => (
        <div className="videoPart">
          <video width="320" height="240" controls>
            <source src={`http://localhost:3001/${video}`} />
            Your browser does not support the video tag.
          </video>
        </div>
      ))}

        <div className="detailPart">
          <div>
            <h2 className="recipe-name">{recipe.name}</h2>
          </div>
          <div>
            <p className="recipe-instructions">{recipe.instructions}</p>
         
          </div>
          <div>
            <h3>Ingredients</h3>
            <h3>{recipe.ingredients}</h3>
          </div>
          <div>
            <p className="cooking-time">Cooking Time: {recipe.cookingTime}  (minutes)</p>
          </div>
        </div>
      </div>
      ))}
    </div>
  );
};

export default MyVideos;
